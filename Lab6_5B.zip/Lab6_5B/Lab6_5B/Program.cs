﻿using System;

namespace Lab6_5B
{
    class Program
    {
        static int  factorialNum, sign = 1;

        static double sumOfProg = 0, x, sum;
        static void Main()
        {
            Console.WriteLine("Endless sum finder \n Enter precision: ");

            double precision = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter x: ");

            x = Convert.ToDouble(Console.ReadLine());
            int i = 0;
            do
            {
            
                    sumOfProg += (sign * (int)Math.Pow(x, i) / Factorial(i)); // знаходимо нескінченну суму 
                    sign *= -1;
                    i++;
     
                Console.WriteLine("\n ________________ \n"
                    + sumOfProg
                    + "\n ________________ \n");
                sum = Math.Abs(sumOfProg - MathF.Exp(-(float)x));

            } while (sum > precision);
        }
       static  int Factorial(int iVar)
        {
            if (iVar == 0)
                return 1;
            else if (iVar == 1)
                return 1;

            factorialNum = iVar;
            for (int i = 0; i < iVar; i++)
            {   
                factorialNum *= --iVar;
            }
            return factorialNum;
        }
    }
}
